# Bayesian A/B Testing

**Question:** *(fill in)* Did the treatment (ad) increase conversion rate over control (PSA), expressed as a direct probability rather than a p-value?

**Key findings:** *(fill in after running; P(treatment better), the credible interval, and your recommendation)*

**Tools:** R, Beta-Binomial Bayesian model (base R — no Stan/brms compilation needed), tidyverse, Quarto

## Why this project — and how it contrasts with ab-test-analysis

This portfolio already has an `ab-test-analysis` project asking the same kind of question with the standard **frequentist** toolkit (`prop.test`, a p-value, a confidence interval). This project asks the same kind of question on the same kind of data, but with a genuinely different statistical framework: **Bayesian inference**. The two projects are deliberately comparable — same data shape, same business question — so the contrast in *how each framework answers it* is the real point, not just a second A/B test.

The headline practical difference: a p-value tells you how surprising your data would be if there were truly no effect. A Bayesian posterior tells you, directly, **"there's an 87% probability the treatment is actually better"** — a statement a p-value can never honestly make, however it's phrased.

## Reproduce

1. Get data: run `source("R/00_simulate_data.R")` for a ready-to-use simulated dataset, **or** substitute the real Kaggle "Marketing A/B Testing" dataset (see `R/00_get_data.R`)
2. `install.packages(c("tidyverse", "janitor", "scales", "quarto"))` — note this project deliberately uses the analytical Beta-Binomial model, not a Stan-based package like `brms`, so there's no compiler/C++ toolchain requirement
3. Run in order:
   - `R/01_clean.R`
   - `R/02_bayesian_analysis.R` (fits posteriors, compares groups, runs sequential monitoring)
   - Render `reports/report.qmd`

## Method in brief

1. **Model each group's conversion rate as a Beta distribution.** A Beta prior, combined with binomial conversion data, produces a Beta posterior — a closed-form update with no simulation needed for this step (Beta is the *conjugate prior* for binomial data).
2. **Start from a neutral prior**, Beta(1,1) — "any conversion rate is equally plausible before data." This choice is explicit and inspectable, unlike a frequentist test's implicit assumptions.
3. **Compare groups via Monte Carlo simulation**: draw many samples from each posterior, subtract them, and directly read off P(treatment > control) and a credible interval for the difference — no p-value involved.
4. **Add a decision-theoretic layer: expected loss.** Answers "if I pick wrong, how costly is that mistake on average?" — something a probability alone doesn't capture, and a p-value doesn't provide at all.
5. **Demonstrate sequential monitoring**, and explain why checking a Bayesian posterior repeatedly doesn't have the same "peeking" penalty that invalidates a repeatedly-checked frequentist p-value.

## Key concepts

| Concept | Plain-English meaning |
|---|---|
| Prior | What you believed about the conversion rate before seeing data — an explicit, inspectable input |
| Posterior | Updated belief after combining the prior with observed data |
| Conjugate prior | A prior chosen so the posterior has a clean closed-form formula (Beta + Binomial = Beta) |
| Credible interval | A direct probability statement: "there's a 95% probability the true value is in this range" — subtly different from a frequentist confidence interval's meaning |
| P(treatment > control) | The direct probability the treatment is truly better — computed by simulating from both posteriors and comparing |
| Expected loss | The average cost of choosing wrong, if you did — a decision-theoretic addition a p-value doesn't provide |
| Peeking problem | Why repeatedly checking a frequentist p-value and stopping early inflates false positives, and why a Bayesian posterior is more robust to this |

## Project structure

```
R/00_get_data.R           real-data source notes
R/00_simulate_data.R      generates simulated A/B test data (same structure as ab-test-analysis)
R/cleaning.R                cleaning function
R/01_clean.R                 run cleaning
R/bayesian_functions.R        Beta-Binomial model, posterior comparison, sequential monitoring (heavily commented)
R/02_bayesian_analysis.R       run the full analysis
reports/report.qmd              full write-up: method contrast with frequentist testing, posterior visualization, decision framing
```

## Limitations

*(fill in — see the report's own Limitations section: prior choice affects the result, no covariate adjustment here, sequential monitoring shown is illustrative not a formal stopping rule)*
