# Reusable functions for a Bayesian A/B test on a binary (converted /
# not converted) outcome, using the Beta-Binomial conjugate model.
# This is a DIFFERENT statistical framework than the ab-test-analysis
# project's frequentist prop.test() + p-value approach -- not just a
# different function call, but a different way of reasoning about
# uncertainty. The comments here are deliberately heavy on explaining
# WHY the Bayesian answer looks and behaves differently, since that
# contrast is the main thing worth understanding from this project.

library(dplyr)
library(tibble)
library(purrr)

#' Update a Beta prior with observed binomial data to get a Beta
#' posterior -- this works because Beta is the CONJUGATE prior for a
#' binomial likelihood, meaning the posterior has a closed FORM (no
#' simulation or numerical approximation needed): a Beta prior, after
#' seeing binomial data, is simply another Beta distribution.
#'
#' @param prior_alpha, prior_beta Parameters of the Beta prior.
#' @param successes Number of conversions observed.
#' @param trials Number of users observed (successes + non-conversions).
#' @return A list: posterior_alpha, posterior_beta.
update_beta_posterior <- function(prior_alpha, prior_beta, successes, trials) {
  list(
    posterior_alpha = prior_alpha + successes,
    posterior_beta  = prior_beta + (trials - successes)
  )
}

#' Fit Beta posteriors for both groups of an A/B test from raw
#' (test_group, converted) data.
#'
#' @param df A data frame with test_group ("control"/"treatment") and
#'   logical converted.
#' @param prior_alpha, prior_beta Shared prior for both groups. The
#'   default (1, 1) is a "uniform" prior -- it says any conversion rate
#'   from 0% to 100% is equally plausible before seeing any data, the
#'   most neutral starting point. A more informed prior (e.g. from a
#'   previous similar test) could be used instead, and WOULD change the
#'   result -- unlike a frequentist test, a Bayesian one is explicit
#'   that its answer depends partly on what you believed beforehand.
#' @return A tibble: group, prior_alpha, prior_beta, successes, trials,
#'   posterior_alpha, posterior_beta.
fit_group_posteriors <- function(df, prior_alpha = 1, prior_beta = 1) {
  df |>
    group_by(test_group) |>
    summarise(successes = sum(converted), trials = n(), .groups = "drop") |>
    rowwise() |>
    mutate(
      posterior = list(update_beta_posterior(prior_alpha, prior_beta, successes, trials))
    ) |>
    ungroup() |>
    mutate(
      prior_alpha     = prior_alpha,
      prior_beta      = prior_beta,
      posterior_alpha = map_dbl(posterior, "posterior_alpha"),
      posterior_beta  = map_dbl(posterior, "posterior_beta")
    ) |>
    select(-posterior)
}

#' Compare two groups' posteriors via Monte Carlo simulation: draw many
#' samples from each group's posterior distribution, then directly
#' compute quantities a stakeholder actually cares about.
#'
#' This is the core practical advantage of the Bayesian approach for
#' this kind of question: instead of a p-value (the probability of
#' data this extreme IF there were truly no difference -- a statement
#' about data you didn't observe, under a hypothesis you don't believe),
#' you get a direct, intuitive answer: "there's an 87% probability
#' treatment truly has a higher conversion rate than control."
#'
#' @param posteriors Output of fit_group_posteriors(), must have rows
#'   for both "control" and "treatment".
#' @param n_draws Number of Monte Carlo samples.
#' @return A list: draws (the raw simulated differences), and a summary
#'   tibble of P(treatment > control), the credible interval for the
#'   difference, and expected loss for each decision.
compare_posteriors <- function(posteriors, n_draws = 100000) {
  control   <- posteriors |> filter(test_group == "control")
  treatment <- posteriors |> filter(test_group == "treatment")

  control_draws   <- rbeta(n_draws, control$posterior_alpha, control$posterior_beta)
  treatment_draws <- rbeta(n_draws, treatment$posterior_alpha, treatment$posterior_beta)

  diff_draws <- treatment_draws - control_draws

  prob_treatment_better <- mean(diff_draws > 0)

  # Expected loss: if we chose "treatment" but control was actually
  # better, how much conversion rate would we lose on average (and vice
  # versa)? This directly answers "what's the downside risk of picking
  # wrong," which a p-value alone never tells you -- a clinically
  # useful decision-theoretic framing a p-value doesn't provide.
  expected_loss_choosing_treatment <- mean(pmax(control_draws - treatment_draws, 0))
  expected_loss_choosing_control   <- mean(pmax(treatment_draws - control_draws, 0))

  list(
    control_draws = control_draws,
    treatment_draws = treatment_draws,
    diff_draws = diff_draws,
    summary = tibble(
      prob_treatment_better = prob_treatment_better,
      diff_mean             = mean(diff_draws),
      diff_ci_low           = quantile(diff_draws, 0.025),
      diff_ci_high          = quantile(diff_draws, 0.975),
      expected_loss_treatment = expected_loss_choosing_treatment,
      expected_loss_control   = expected_loss_choosing_control
    )
  )
}

#' Simulate how the posterior P(treatment > control) would have
#' evolved if we'd checked it after every N new users, rather than
#' only at the end. This is the other major practical difference from
#' the frequentist approach: a frequentist p-value becomes unreliable
#' if you "peek" at it repeatedly and stop as soon as it crosses 0.05
#' (inflating the false-positive rate). The Bayesian posterior doesn't
#' have this problem in the same way -- it's a valid, honestly-updated
#' belief at EVERY point in time, so checking it whenever you like
#' doesn't invalidate it the way repeated peeking does for a p-value.
#'
#' @param df Cleaned ab-test data, in roughly the order it was collected.
#' @param checkpoint_every Check the posterior every N rows.
#' @param prior_alpha, prior_beta Shared prior for both groups.
#' @return A tibble: n_observed, prob_treatment_better.
sequential_monitoring <- function(df, checkpoint_every = 200, prior_alpha = 1, prior_beta = 1) {
  n_total <- nrow(df)
  checkpoints <- seq(checkpoint_every, n_total, by = checkpoint_every)

  map_dfr(checkpoints, function(n) {
    subset_df <- df[seq_len(n), ]
    posteriors <- fit_group_posteriors(subset_df, prior_alpha, prior_beta)
    if (n_distinct(posteriors$test_group) < 2) return(NULL)   # not enough data yet for both groups
    comp <- compare_posteriors(posteriors, n_draws = 5000)
    tibble(n_observed = n, prob_treatment_better = comp$summary$prob_treatment_better)
  })
}
