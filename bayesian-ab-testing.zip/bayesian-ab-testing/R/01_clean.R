library(readr)
source("R/cleaning.R")

raw   <- read_csv("data/raw/ab_test_data.csv", show_col_types = FALSE)
clean <- clean_ab(raw)

cat("Rows:", nrow(clean), "\n")
print(table(clean$test_group))

saveRDS(clean, "data/clean/ab_clean.rds")
