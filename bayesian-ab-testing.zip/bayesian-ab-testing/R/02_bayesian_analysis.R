library(dplyr)
source("R/bayesian_functions.R")

df <- readRDS("data/clean/ab_clean.rds")

# Prior: uniform Beta(1,1) -- "any conversion rate is equally plausible
# before seeing data." See fit_group_posteriors() documentation for why
# this choice matters and how it differs from frequentist assumptions.
posteriors <- fit_group_posteriors(df, prior_alpha = 1, prior_beta = 1)
cat("=== Posterior parameters per group ===\n")
print(posteriors)

comparison <- compare_posteriors(posteriors, n_draws = 100000)
cat("\n=== Comparison summary ===\n")
print(comparison$summary)

cat(sprintf(
  "\nP(treatment truly better than control): %.1f%%\n",
  comparison$summary$prob_treatment_better * 100
))
cat(sprintf(
  "95%% credible interval for the difference: [%.4f, %.4f]\n",
  comparison$summary$diff_ci_low, comparison$summary$diff_ci_high
))

# Sequential monitoring: how would this posterior have looked if we'd
# checked it every 200 users instead of waiting for the full sample?
seq_monitor <- sequential_monitoring(df, checkpoint_every = 200)
cat("\n=== Sequential monitoring (posterior probability over time) ===\n")
print(seq_monitor)

saveRDS(list(
  posteriors = posteriors, comparison = comparison,
  seq_monitor = seq_monitor
), "data/clean/bayesian_results.rds")
