library(dplyr)
library(janitor)

clean_ab <- function(raw) {
  raw |>
    clean_names() |>
    mutate(
      test_group = factor(test_group, levels = c("control", "treatment")),
      converted  = as.logical(converted)
    ) |>
    filter(!is.na(test_group), !is.na(converted))
}
