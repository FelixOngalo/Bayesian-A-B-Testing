# Data for this project: the SAME kind of marketing A/B test data used
# in the ab-test-analysis project (control vs. treatment, binary
# conversion outcome) -- reused deliberately, so the two projects are
# directly comparable: same question, same data shape, two different
# statistical frameworks (frequentist vs. Bayesian).
#
# OPTION A (real data): Kaggle "Marketing A/B Testing"
#   (search that title on kaggle.com). Save as data/raw/marketing_AB.csv
#
# OPTION B (runs immediately, no download): simulated data with the
#   same structure. Run R/00_simulate_data.R.

message("Use Option A (download Marketing A/B Testing) or Option B (source('R/00_simulate_data.R')).")
