# Simulate a marketing A/B test: control (PSA) vs treatment (ad),
# binary conversion outcome. Same generative structure as the
# ab-test-analysis project's simulated data, for direct comparability.

library(dplyr)
library(readr)

set.seed(42)

n           <- 4000          # smaller than the frequentist project's dataset on purpose --
                              # Bayesian methods are especially useful with SMALLER samples,
                              # where a frequentist p-value is more likely to be ambiguous
ad_share    <- 0.5
p_control   <- 0.10          # true conversion rate, PSA (control)
p_treatment <- 0.12          # true conversion rate, ad (treatment) -- a modest, realistic lift

sim <- tibble(
  user_id    = seq_len(n),
  test_group = sample(c("control", "treatment"), n, replace = TRUE, prob = c(1 - ad_share, ad_share))
) |>
  mutate(
    converted = runif(n) < if_else(test_group == "treatment", p_treatment, p_control)
  )

dir.create("data/raw", showWarnings = FALSE, recursive = TRUE)
write_csv(sim, "data/raw/ab_test_data.csv")
message("Wrote simulated data to data/raw/ab_test_data.csv (", nrow(sim), " rows)")
