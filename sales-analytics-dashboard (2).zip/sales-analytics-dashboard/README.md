# Retail Sales Analytics Dashboard

**Question:** *(fill in)* How is revenue trending, which products and markets drive it, and which customer segments matter most?

**Key findings:** *(fill in after running the analysis; 2-3 bullets with numbers)*

**Tools:** R, tidyverse, RFM segmentation, Quarto report, Shiny dashboard

## Reproduce

1. Download the "Online Retail II" dataset (see `R/00_get_data.R` for links) and place it at `data/raw/online_retail_II.xlsx`
2. `install.packages(c("tidyverse", "readxl", "janitor", "lubridate", "scales", "gt", "shiny", "quarto"))`
3. Run in order:
   - `R/01_clean.R` cleans the raw transactions
   - `R/02_rfm.R` computes customer segments (Recency, Frequency, Monetary)
   - Render `reports/report.qmd` for the written analysis
   - `shiny::runApp("app")` for the interactive dashboard

## Data

UCI Machine Learning Repository / Kaggle: "Online Retail II", real transactions from a UK-based online retailer, Dec 2009-Dec 2011.

## Method: RFM segmentation

Customers are scored on three dimensions and split into quartiles:
- **Recency** – days since their last order (more recent is better)
- **Frequency** – number of distinct orders
- **Monetary** – total revenue

Combined scores map to segments: Champions, Loyal, New/Promising, At Risk, Needs Attention, Lost.

## Project structure

```
R/00_get_data.R      links to the raw data (manual download)
R/cleaning.R          cleaning functions
R/01_clean.R          run cleaning, save cleaned data
R/rfm.R                RFM segmentation function
R/02_rfm.R            run segmentation, save results
reports/report.qmd    written analysis and charts
app/app.R              interactive Shiny dashboard
```

## Security scanning the live Shiny app (optional)

The Shiny app in `app/app.R` is a live web application once deployed (e.g. to shinyapps.io, Posit Connect, or a self-hosted Shiny Server) — unlike the static Quarto report, it accepts user input (the country and date-range filters) and serves a running R process, so it's worth a basic security check before sharing the link publicly. [NeuraLegion](https://www.neuralegion.com) (now part of [Bright Security](https://brightsec.com)) is a DAST (Dynamic Application Security Testing) tool that scans a *running* app for real vulnerabilities — injection flaws, broken access control, exposed debug endpoints — rather than reading the source code.

This isn't wired into automated CI here, since DAST scanning needs a live, deployed URL to point at (not just a GitHub push), but here's how to run one manually once the app is deployed:

1. **Deploy the app** to get a live URL, e.g. via [shinyapps.io](https://www.shinyapps.io) (`rsconnect::deployApp("app")`) or Posit Connect.
2. **Sign up for Bright Security** at [brightsec.com](https://brightsec.com) and create a project; generate an API key under your account settings.
3. **Run a scan** against the deployed URL. Bright's CLI (`brightsec-cli` / `repeater`) can do this from a terminal:
   ```bash
   npx @neuralegion/bright-cli scan:run \
     --name "sales-analytics-dashboard" \
     --target "https://your-deployed-url.shinyapps.io/sales-analytics-dashboard/" \
     --api-key "$BRIGHT_API_KEY"
   ```
4. **Review the report** in the Bright dashboard — for a Shiny app specifically, pay attention to input-validation findings on the country/date filters, since those are the only two user-controlled inputs the server-side code processes.
5. **Re-scan after any change** to `app/app.R`, especially if you add new `input$` fields — each new piece of user input is a new potential attack surface.

**Why this matters for a portfolio app specifically:** a public Shiny app with no authentication is reachable by anyone with the link. A basic DAST pass is a low-effort way to confirm nothing in the filter inputs can be abused (e.g. to crash the R process or probe the server) before you link it from a resume or LinkedIn.

## Limitations

*(fill in)*
