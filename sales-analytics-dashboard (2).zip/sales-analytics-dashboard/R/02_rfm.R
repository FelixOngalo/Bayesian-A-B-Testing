library(dplyr)
source("R/rfm.R")

clean <- readRDS("data/clean/retail_clean.rds")
rfm <- compute_rfm(clean)

rfm |> count(segment, sort = TRUE) |> print(n = Inf)

saveRDS(rfm, "data/clean/rfm.rds")
