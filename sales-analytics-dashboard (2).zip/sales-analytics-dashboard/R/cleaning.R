# Cleaning helpers for the retail transaction data.

library(dplyr)
library(stringr)
library(lubridate)
library(janitor)

clean_retail <- function(raw) {
  raw |>
    clean_names() |>
    # UCI column names vary by sheet/year; rename defensively
    rename(any_of(c(
      invoice_no   = "invoice",
      stock_code   = "stockcode",
      description  = "description",
      quantity     = "quantity",
      invoice_date = "invoicedate",
      unit_price   = "price",
      customer_id  = "customer_id",
      country      = "country"
    ))) |>
    mutate(
      description  = str_squish(str_to_upper(description)),
      invoice_date = as_datetime(invoice_date),
      is_cancelled = str_starts(as.character(invoice_no), "C"),
      revenue      = quantity * unit_price
    ) |>
    filter(
      !is.na(customer_id),
      !is_cancelled,
      quantity > 0,
      unit_price > 0
    ) |>
    mutate(
      order_month = floor_date(invoice_date, "month"),
      order_date  = as_date(invoice_date)
    )
}
