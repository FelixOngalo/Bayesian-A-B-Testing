# Get the dataset: "Online Retail II" (UCI ML Repository / also on Kaggle).
# Real e-commerce transactions from a UK-based retailer, 2009-2011.
# Manually download the XLSX from one of these and place it at data/raw/online_retail_II.xlsx:
#   https://archive.ics.uci.edu/dataset/502/online+retail+ii
#   https://www.kaggle.com/datasets/mashlyn/online-retail-ii-uci
#
# Alternative if you'd rather not download anything: swap in any transaction-level
# dataset with columns for order id, customer id, product, quantity, price, and date.

message("Download the dataset manually and place it at data/raw/online_retail_II.xlsx")
message("See comments in this file for source links.")
