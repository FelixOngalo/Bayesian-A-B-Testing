# RFM segmentation: Recency, Frequency, Monetary value.
# Standard technique for identifying customer segments in a retail dataset.

library(dplyr)
library(lubridate)

compute_rfm <- function(df, snapshot_date = NULL) {
  if (is.null(snapshot_date)) snapshot_date <- max(df$order_date) + days(1)

  rfm <- df |>
    group_by(customer_id) |>
    summarise(
      recency_days = as.numeric(snapshot_date - max(order_date)),
      frequency    = n_distinct(invoice_no),
      monetary     = sum(revenue),
      .groups = "drop"
    ) |>
    mutate(
      r_score = ntile(-recency_days, 4),   # more recent = higher score
      f_score = ntile(frequency, 4),
      m_score = ntile(monetary, 4),
      rfm_score = r_score + f_score + m_score,
      segment = case_when(
        r_score >= 4 & f_score >= 4               ~ "Champions",
        r_score >= 3 & f_score >= 3                ~ "Loyal",
        r_score >= 4 & f_score <= 2                ~ "New / Promising",
        r_score <= 2 & f_score >= 3                ~ "At Risk",
        r_score <= 2 & f_score <= 2 & m_score <= 2  ~ "Lost",
        TRUE                                        ~ "Needs Attention"
      )
    )

  rfm
}
