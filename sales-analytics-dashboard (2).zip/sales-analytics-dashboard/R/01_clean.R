library(readxl)
library(dplyr)
source("R/cleaning.R")

raw <- read_excel("data/raw/online_retail_II.xlsx")
clean <- clean_retail(raw)

cat("Rows before:", nrow(raw), "\n")
cat("Rows after cleaning:", nrow(clean), "\n")
cat("Unique customers:", n_distinct(clean$customer_id), "\n")
cat("Date range:", as.character(min(clean$order_date)), "to", as.character(max(clean$order_date)), "\n")

saveRDS(clean, "data/clean/retail_clean.rds")
