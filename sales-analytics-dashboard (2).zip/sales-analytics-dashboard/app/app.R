# Shiny dashboard: interactive view of revenue and customer segments.
# Run with: shiny::runApp("app")

library(shiny)
library(tidyverse)
library(scales)

df  <- readRDS("../data/clean/retail_clean.rds")
rfm <- readRDS("../data/clean/rfm.rds")

ui <- fluidPage(
  titlePanel("Retail Sales Dashboard"),
  sidebarLayout(
    sidebarPanel(
      selectInput(
        "country", "Country",
        choices = c("All", sort(unique(df$country))),
        selected = "All"
      ),
      dateRangeInput(
        "dates", "Date range",
        start = min(df$order_date), end = max(df$order_date),
        min = min(df$order_date), max = max(df$order_date)
      ),
      hr(),
      helpText("Filters apply to the revenue chart and KPIs. The segment chart uses all customers.")
    ),
    mainPanel(
      fluidRow(
        column(4, h4("Revenue"), textOutput("kpi_revenue")),
        column(4, h4("Orders"), textOutput("kpi_orders")),
        column(4, h4("Customers"), textOutput("kpi_customers"))
      ),
      plotOutput("revenue_plot"),
      plotOutput("segment_plot")
    )
  )
)

server <- function(input, output, session) {

  filtered <- reactive({
    d <- df |> filter(order_date >= input$dates[1], order_date <= input$dates[2])
    if (input$country != "All") d <- d |> filter(country == input$country)
    d
  })

  output$kpi_revenue   <- renderText(dollar(sum(filtered()$revenue)))
  output$kpi_orders    <- renderText(n_distinct(filtered()$invoice_no))
  output$kpi_customers <- renderText(n_distinct(filtered()$customer_id))

  output$revenue_plot <- renderPlot({
    filtered() |>
      group_by(order_month) |>
      summarise(revenue = sum(revenue)) |>
      ggplot(aes(order_month, revenue)) +
      geom_line(linewidth = 1) + geom_point() +
      scale_y_continuous(labels = label_dollar()) +
      labs(title = "Monthly revenue", x = NULL, y = NULL) +
      theme_minimal(base_size = 13)
  })

  output$segment_plot <- renderPlot({
    rfm |>
      count(segment, sort = TRUE) |>
      ggplot(aes(n, fct_reorder(segment, n))) +
      geom_col() +
      labs(title = "Customers per segment", x = "Customers", y = NULL) +
      theme_minimal(base_size = 13)
  })
}

shinyApp(ui, server)
